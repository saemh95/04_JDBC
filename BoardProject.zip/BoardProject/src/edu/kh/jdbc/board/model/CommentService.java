package edu.kh.jdbc.board.model;

import java.sql.Connection;

import edu.kh.jdbc.board.dao.CommentDAO;
import static edu.kh.jdbc.common.JDBCTemplate.*;

public class CommentService {
	
	private CommentDAO dao = new CommentDAO();

	/** 댓글 등록 서비스
	 * @param boardNo
	 * @param string
	 * @param memberNo
	 * @return result
	 */
	public int insertComment(int boardNo, String commentContent, int memberNo) throws Exception{
		Connection conn = getConnection();
		
		int result = dao.insertComment(conn, boardNo, commentContent, memberNo);
		
		if(result > 0) {
			commit(conn);
		} else {
			rollback(conn);
		}
		
		close(conn);
		
		return result;
	}
	
	
	
	
}
